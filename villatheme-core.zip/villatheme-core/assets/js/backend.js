(function ($) {
    "use strict";
    $(document).ready(function () {
        $(document).on('click', '.select-widget-image', function (e) {
            e.preventDefault();

            var button = $(this);
            var container = button.closest('.villa-widget-image-field');
            var input = container.find('.villa-widget-image-url');
            var image = container.find('img');

            var custom_uploader = wp.media({
                title: 'Select Image',
                button: {text: 'Use this image'},
                multiple: false
            }).on('select', function () {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                input.val(attachment.url);
                image.attr('src', attachment.url).show();
            }).open();
        });
        //CUSTOM FIELD
        const $layoutSelect = $('select[name="page_sidebar_layout"]');
        const $sidebarField = $('.page_sidebar');
        function toggleSidebarField() {
           const layoutVal = $layoutSelect.val();
           const isFull = layoutVal === 'full';
           $sidebarField.toggle(!isFull);
        }
        if ( $layoutSelect.length && $sidebarField.length) {
           toggleSidebarField();
           $layoutSelect.on('change', toggleSidebarField);
        }

        const $enableHeader = $('input[name="enable_header"]');
        const $headerLayoutField = $('.metabox_header_options');
        function toggleHeaderLayoutField() {
            const isChecked = $enableHeader.is(':checked');
            $headerLayoutField.toggle(isChecked);
        }
        if ($enableHeader.length && $headerLayoutField.length) {
             toggleHeaderLayoutField();
             $enableHeader.on('change', toggleHeaderLayoutField);
        }

        const $enableFooter = $('input[name="enable_footer"]');
        const $footerLayoutField = $('.metabox_footer_options');
        function toggleFooterLayoutField() {
            const isChecked = $enableFooter.is(':checked');
            $footerLayoutField.toggle(isChecked);
        }
        if ($enableFooter.length && $footerLayoutField.length) {
             toggleFooterLayoutField();
             $enableFooter.on('change', toggleFooterLayoutField);
        }

        let frame;

        $(document).on('click', '.villa-gallery-upload', function (e) {
            e.preventDefault();

            const $button = $(this);
            const $input = $button.siblings('.villa-gallery-input');
            const $preview = $button.siblings('.villa-gallery-preview');

            if (frame) {
                frame.open();
                return;
            }

            frame = wp.media({
                title: 'Select Gallery Images',
                multiple: true,
                library: { type: 'image' },
                button: { text: 'Use Images' }
            });

            frame.on('select', function () {
                const selection = frame.state().get('selection');
                const ids = [];
                $preview.empty();

                selection.each(function (attachment) {
                    const id = attachment.id;
                    ids.push(id);

                    const thumb = attachment.attributes.sizes?.thumbnail?.url || attachment.attributes.url;

                    $preview.append(`
                        <span class="villa-gallery-thumb" data-id="${id}">
                            <img src="${thumb}" />
                            <span class="villa-gallery-delete">&times;</span>
                        </span>
                    `);
                });

                $input.val(ids.join(','));
            });

            frame.open();
        });

        $(document).on('click', '.villa-gallery-delete', function (e) {
            e.preventDefault();

            const $item = $(this).closest('.villa-gallery-thumb');
            const idToRemove = $item.data('id');
            const $preview = $item.closest('.villa-gallery-preview');
            const $input = $preview.siblings('.villa-gallery-input');

            let ids = $input.val().split(',').filter(id => id && id != idToRemove);
            $input.val(ids.join(','));
            $item.remove();
        });

        const togglePostFormat = (radioId) => {
            const $radio = $(radioId);
            if (!$radio.length) return;

            const $galleryPost = $('.gallery-post-wrapper');
            const $videoPost = $('.video-post-wrapper');

            const togglePost = () => {
                const radioVal = $radio.filter(':checked').val();
                $galleryPost.toggle(radioVal === 'gallery');
                $videoPost.toggle(radioVal === 'video');
            };

            togglePost();
            $radio.on('change', togglePost);
        };
        togglePostFormat('#post-formats-select input[name="post_format"]');

        const toggleProductFormat = (selectId) => {
            const $select = $(selectId);
            if (!$select.length) return;

            const $productVideo = $('.video-product-wrapper');
            const $product360deg = $('.gallery-product-wrapper');

            const toggleProduct = () => {
                const selectVal = $select.val();
                $productVideo.toggle(selectVal === 'video');
                $product360deg.toggle(selectVal === '360deg');
            };

            toggleProduct();
            $select.on('change', toggleProduct);
        };
        toggleProductFormat('#product_options');
        //ocdi
        $('.js-ocdi-install-plugins-before-import').on('click', function(){
            let lastPct = 0;
            let delay = 100;
            const $wrap = $('<div id="villa-progress-wrap"><div id="villa-progress-bar"><span class="progress-active"></span><span class="progress-text">0%</span></div><div id="villa-progress-msg">Waiting to start import...</div></div>');
            $('.ocdi-importing').append($wrap);
            function updateUI(data){
               $('#villa-progress-bar .progress-active').css('width', data.percent + '%');
               $('#villa-progress-bar .progress-text').text(data.percent + '%');
               $('#villa-progress-msg').text(data.message);
            }
            function poll(){
                $.post(villatheme_ajax_backend.ajax_url, {
                    action: 'villa_import_progress'
                }).done(function(res){
                    if(res.success){
                        let pct = parseInt(res.data.percent, 10) || 0;
                        if (pct >= 10 && pct < 97) {
                            let inc = Math.floor(Math.random() * 4) + 2;
                            lastPct = Math.min(97, Math.max(10, lastPct + inc));
                            delay = 10000;
                        } else {
                            lastPct = pct;
                            delay = 100;
                        }
                        res.data.percent = lastPct;
                        updateUI(res.data);
                        setTimeout(poll, delay);
                    }
                });
            }
            poll();
        });
    });

})(jQuery);
