<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( ! class_exists( 'Villa_Dashboard' ) ) {
	class Villa_Dashboard {
		public $theme_name;

		public function __construct() {
			$this->theme_name = wp_get_theme()->get( 'Name' );
			add_action( 'admin_menu', array( $this, 'admin_menu' ), 1 );
		}

		public function admin_menu() {
			if ( current_user_can( 'edit_theme_options' ) ) {
				add_menu_page( 'VillaTheme Core', 'VillaTheme Core', 'manage_options', 'villa_dashboard', array(
					$this,
					'dashboard'
				), VILLATHEME_CORE_URL . '/assets/images/menu-icon.png', 2 );
				add_submenu_page( 'villa_dashboard', 'Villa Dashboard', 'Dashboard', 'manage_options', 'villa_dashboard', array(
					$this,
					'dashboard'
				) );
			}
		}

		/**
		 * Render HTML of intro tab.
		 *
		 * @return  string
		 */

		public function dashboard() {
			?>
            <div class="wrap">
                <div class="villa-dashboard">
                    <div class="logo-demo">
                        <a href="https://villatheme.com/">
                            <img src="<?php echo esc_url( VILLATHEME_CORE_URL . 'assets/images/logo.png' ); ?>"
                                 alt="<?php echo esc_attr__( 'logo', 'villatheme-core' ) ?>"></a>
                    </div>
                    <h4 class="info-theme">
						<?php esc_html_e( 'VillaTheme.com is your premier source for high-quality WooCommerce and WordPress products. Our commitment to excellence ensures that our products empower your online presence and e-commerce capabilities. We offer innovative solutions that set the standard for quality and performance, making us a hub of creativity and innovation in the WordPress product space.', 'villatheme-core' ) ?>
                    </h4>
                    <div class="rp-row">
                        <div class="rp-col">
                            <div class="support-item doc-item">
                                <i class="icon fa fa-book"></i>
                                <h3><a target="_blank"
                                       href="<?php echo esc_url( 'https://docs.villatheme.com/?item=' . strtolower( $this->theme_name ) ); ?>"><?php esc_html_e( 'Documentation', 'villatheme-core' ); ?></a>
                                </h3>
                                <p><?php esc_html_e( 'Here is our user guide, including basic setup steps, as well as features for your reference.', 'villatheme-core' ); ?></p>
                            </div>
                        </div>
                        <div class="rp-col">
                            <div class="support-item video-item">
                                <i class="icon fa fa-question"></i>
                                <h3><a target="_blank"
                                       href="<?php echo esc_url( 'https://villatheme.com/faqs/' ); ?>"><?php esc_html_e( 'FAQs', 'villatheme-core' ); ?></a>
                                </h3>
                                <p><?php esc_html_e( 'Regular questions & answers are presented here in the FAQs area.', 'villatheme-core' ); ?></p>
                            </div>
                        </div>
                        <div class="rp-col">
                            <div class="support-item forum-item">
                                <i class="icon fa fa-comment"></i>
                                <h3><a target="_blank"
                                       href="<?php echo esc_url( 'https://villatheme.com/supports/' ); ?>"><?php esc_html_e( 'Support Forum', 'villatheme-core' ); ?></a>
                                </h3>
                                <p><?php esc_html_e( 'You can also easy to find out the answer over existing topics on the support forum.', 'villatheme-core' ); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
	}

	new Villa_Dashboard();
}
