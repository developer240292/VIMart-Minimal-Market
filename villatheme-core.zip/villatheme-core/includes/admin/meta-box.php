<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( ! class_exists( 'Villa_Custom_Meta_Box' ) ) {
	class Villa_Custom_Meta_Box {
		public function __construct() {
			add_action( 'add_meta_boxes', array( $this, 'add_custom_meta_boxes' ) );
			add_action( 'save_post', array( $this, 'save_meta_box_data' ) );
		}

		public function add_custom_meta_boxes() {
			add_meta_box( 'villa_page_options', __( 'Custom Page Options', 'villatheme-core' ), array(
				$this,
				'render_page_meta_box'
			), 'page', 'normal', 'default' );
			add_meta_box( 'villa_post_options', __( 'Custom Post Options', 'villatheme-core' ), array(
				$this,
				'render_post_meta_box'
			), 'post', 'normal', 'default' );
			add_meta_box( 'villa_product_options', __( 'Custom Product Options', 'villatheme-core' ), array(
				$this,
				'render_product_meta_box'
			), 'product', 'normal', 'default' );
		}

		private function get_meta_value( $post_id, $key, $default = '' ) {
			$value = get_post_meta( $post_id, $key, true );

			return ! empty( $value ) ? $value : $default;
		}

		private function get_header_preview() {
			$layoutDir      = get_template_directory() . '/templates/header/';
			$header_options = array();
			if ( is_dir( $layoutDir ) ) {
				$files = scandir( $layoutDir );
				if ( $files && is_array( $files ) ) {
					foreach ( $files as $file ) {
						if ( $file != '.' && $file != '..' ) {
							$fileInfo = pathinfo( $file );
							if ( $fileInfo['extension'] == 'php' && $fileInfo['basename'] != 'index.php' ) {
								$file_name                    = $fileInfo['filename'];
								$header_options[ $file_name ] = get_theme_file_uri( '/templates/header/' . $file_name . '.jpg' );
							}
						}
					}
				}
			}

			return $header_options;
		}

		private function get_footer_preview() {
			$footer_preview = array(
				'none',
			);
			$args           = array(
				'post_type'      => 'villa_footer',
				'posts_per_page' => - 1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			);
			$posts          = get_posts( $args );
			if ( ! empty( $posts ) ) {
				foreach ( $posts as $post ) {
					setup_postdata( $post );
					$footer_preview[] = $post->post_name;
				}
			}
			wp_reset_postdata();

			return $footer_preview;
		}

		private function get_sidebar_options() {
			global $wp_registered_sidebars;
			$sidebars = array();
			foreach ( $wp_registered_sidebars as $id => $sidebar ) {
				$sidebars[ $id ] = $sidebar['name'];
			}

			return $sidebars;
		}

		public function render_page_meta_box( $post ) {
			wp_nonce_field( 'villa_save_meta_box', 'villa_meta_box_nonce' );

			$page_sidebar_layout       = $this->get_meta_value( $post->ID, 'page_sidebar_layout', 'left' );
			$page_sidebar              = $this->get_meta_value( $post->ID, 'page_sidebar', 'widget-area' );
			$page_extra_class          = $this->get_meta_value( $post->ID, 'page_extra_class' );
			$enable_header             = $this->get_meta_value( $post->ID, 'enable_header' );
			$metabox_header_options    = $this->get_meta_value( $post->ID, 'metabox_header_options', 'style-01' );
			$disable_breadcrumb        = $this->get_meta_value( $post->ID, 'disable_breadcrumb' );
			$enable_header_transparent = $this->get_meta_value( $post->ID, 'enable_header_transparent' );
			$enable_footer             = $this->get_meta_value( $post->ID, 'enable_footer' );
			$metabox_footer_options    = $this->get_meta_value( $post->ID, 'metabox_footer_options', 'none' );

			$sidebars = $this->get_sidebar_options();
			?>
            <p class="page_sidebar_layout">
                <label><?php echo esc_html__( 'Sidebar Layout', 'villatheme-core' ); ?></label>
                <select name="page_sidebar_layout" class="widefat">
                    <option value="full" <?php selected( $page_sidebar_layout, 'full' ); ?>>Full</option>
                    <option value="left" <?php selected( $page_sidebar_layout, 'left' ); ?>>Left</option>
                    <option value="right" <?php selected( $page_sidebar_layout, 'right' ); ?>>Right</option>
                </select>
            </p>

            <p class="page_sidebar"><label><?php echo esc_html__( 'Sidebar', 'villatheme-core' ); ?></label>
                <select name="page_sidebar" class="widefat">
					<?php foreach ( $sidebars as $id => $name ) : ?>
                        <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $page_sidebar, $id ); ?>><?php echo esc_html( $name ); ?></option>
					<?php endforeach; ?>
                </select>
            </p>

            <p><label><?php echo esc_html__( 'Extra Page Class', 'villatheme-core' ); ?></label>
                <input type="text" name="page_extra_class" value="<?php echo esc_attr( $page_extra_class ); ?>"
                       class="widefat"/></p>

            <p class="enable_header"><label>
                    <input type="checkbox" name="enable_header" value="1" <?php checked( $enable_header, '1' ); ?> />
					<?php echo esc_html__( 'Enable Custom Header', 'villatheme-core' ); ?></label></p>

            <p class="metabox_header_options">
                <label><?php echo esc_html__( 'Header Layout', 'villatheme-core' ); ?></label>
                <select name="metabox_header_options" class="widefat">
					<?php
					$header_options = $this->get_header_preview();
					foreach ( $header_options as $file_name => $preview ) : ?>
                        <option value="<?php echo esc_attr( $file_name ); ?>" <?php selected( $metabox_header_options, $file_name ); ?>><?php echo esc_html( $file_name ); ?></option>
					<?php endforeach; ?>
                </select></p>

            <p><label><input type="checkbox" name="disable_breadcrumb"
                             value="1" <?php checked( $disable_breadcrumb, '1' ); ?> />
					<?php echo esc_html__( 'Disable Breadcrumb', 'villatheme-core' ); ?></label></p>

            <p><label><input type="checkbox" name="enable_header_transparent"
                             value="1" <?php checked( $enable_header_transparent, '1' ); ?> />
					<?php echo esc_html__( 'Enable Header Transparent', 'villatheme-core' ); ?></label></p>

            <p class="enable_footer"><label><input type="checkbox" name="enable_footer"
                                                   value="1" <?php checked( $enable_footer, '1' ); ?> />
					<?php echo esc_html__( 'Enable Custom Footer', 'villatheme-core' ); ?></label></p>

            <p class="metabox_footer_options">
                <label><?php echo esc_html__( 'Footer Layout', 'villatheme-core' ); ?></label>
                <select name="metabox_footer_options" class="widefat">
					<?php
					$footer_options = $this->get_footer_preview();
					foreach ( $footer_options as $file_name) : ?>
                        <option value="<?php echo esc_attr( $file_name ); ?>" <?php selected( $metabox_footer_options, $file_name ); ?>><?php echo esc_html( $file_name ); ?></option>
					<?php endforeach; ?>
                </select></p>
			<?php
		}

		public function render_post_meta_box( $post ) {
			wp_nonce_field( 'villa_save_meta_box', 'villa_meta_box_nonce' );
			$gallery_post = $this->get_meta_value( $post->ID, 'gallery_post' );
			$video_post   = $this->get_meta_value( $post->ID, 'video_post' );
			?>
            <p class="gallery-post-wrapper">
                <label><?php echo esc_html__( 'Gallery Images', 'villatheme-core' ); ?></label>
                <button type="button"
                        class="button villa-gallery-upload"><?php echo esc_html__( 'Upload Images', 'villatheme-core' ); ?></button>
                <input type="hidden" name="gallery_post" class="villa-gallery-input"
                       value="<?php echo esc_attr( $gallery_post ); ?>"/>
                <span class="villa-gallery-preview">
                    <?php
                    if ( ! empty( $gallery_post ) ) {
	                    $ids = explode( ',', $gallery_post );
	                    foreach ( $ids as $id ) {
		                    $img = wp_get_attachment_image( $id, 'thumbnail' );
		                    if ( $img ) {
			                    echo '<span class="villa-gallery-thumb" data-id="' . esc_attr( $id ) . '">' . $img . ' <span class="villa-gallery-delete">&times;</span></span>';
		                    }
	                    }
                    }
                    ?>
                </span>
            </p>

            <p class="video-post-wrapper"><label><?php echo esc_html__( 'Video URL', 'villatheme-core' ); ?></label>
                <input type="url" name="video_post" value="<?php echo esc_attr( $video_post ); ?>" class="widefat"/></p>
			<?php
		}

		public function render_product_meta_box( $post ) {
			wp_nonce_field( 'villa_save_meta_box', 'villa_meta_box_nonce' );

			$product_style          = $this->get_meta_value( $post->ID, 'product_style', 'global' );
			$product_options        = $this->get_meta_value( $post->ID, 'product_options' );
			$video_product_url      = $this->get_meta_value( $post->ID, 'video_product_url' );
			$degree_product_gallery = $this->get_meta_value( $post->ID, 'degree_product_gallery' );

			$product_styles = array(
				'global'               => esc_html__( 'Use Global Setting', 'villatheme-core' ),
				'horizontal_thumbnail' => esc_html__( 'Horizontal Thumbnail', 'villatheme-core' ),
				'vertical_thumbnail'   => esc_html__( 'Vertical Thumbnail', 'villatheme-core' ),
				'sticky_detail'        => esc_html__( 'Sticky Detail', 'villatheme-core' ),
			);
			?>
            <p><label><?php echo esc_html__( 'Product Style', 'villatheme-core' ); ?></label>
                <select name="product_style" class="widefat">
					<?php foreach ( $product_styles as $key => $label ) : ?>
                        <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $product_style, $key ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
                </select>
            </p>

            <p><label><?php echo esc_html__( 'Format Product', 'villatheme-core' ); ?></label>
                <select name="product_options" class="widefat" id="product_options">
                    <option value=""><?php echo esc_html__( '-- Select --', 'villatheme-core' ); ?></option>
                    <option value="video" <?php selected( $product_options, 'video' ); ?>><?php echo esc_html__( 'Video', 'villatheme-core' ); ?></option>
                    <option value="360deg" <?php selected( $product_options, '360deg' ); ?>><?php echo esc_html__( '360 Degree', 'villatheme-core' ); ?></option>
                </select>
            </p>

            <p class="gallery-product-wrapper">
                <label><?php echo esc_html__( '360 Images', 'villatheme-core' ); ?></label>
                <button type="button"
                        class="button villa-gallery-upload"><?php echo esc_html__( 'Upload Images', 'villatheme-core' ); ?></button>
                <input type="hidden" name="degree_product_gallery" class="villa-gallery-input"
                       value="<?php echo esc_attr( $degree_product_gallery ); ?>"/>
				<?php
				echo '<span class="villa-gallery-preview">';
				if ( ! empty( $degree_product_gallery ) ) {
					$ids = explode( ',', $degree_product_gallery );
					foreach ( $ids as $id ) {
						$img = wp_get_attachment_image( $id, 'thumbnail' );
						if ( $img ) {
							echo '<span class="villa-gallery-thumb" data-id="' . esc_attr( $id ) . '">' . $img . ' <span class="villa-gallery-delete">&times;</span></span>';
						}
					}
				}
				echo '</span>';
				?>
            </p>
            <p class="video-product-wrapper"><label><?php echo esc_html__( 'Video URL', 'villatheme-core' ); ?></label>
                <input type="url" name="video_product_url" value="<?php echo esc_attr( $video_product_url ); ?>"
                       class="widefat"/></p>
			<?php
		}

		public function save_meta_box_data( $post_id ) {
			if ( ! isset( $_POST['villa_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['villa_meta_box_nonce'], 'villa_save_meta_box' ) ) {
				return;
			}
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}

			$fields = array_merge(
				[
					// page
					'page_sidebar_layout',
					'page_sidebar',
					'page_extra_class',
					'enable_header',
					'metabox_header_options',
					'disable_breadcrumb',
					'enable_header_transparent',
					'enable_footer',
					'metabox_footer_options',
					// post
					'gallery_post',
					'video_post',
					// product
					'product_style',
					'product_options',
					'video_product_url',
					'degree_product_gallery',
				]
			);
			foreach ( $fields as $field ) {
				if ( isset( $_POST[ $field ] ) ) {
					$value = $_POST[ $field ];
					switch ( $field ) {
						case 'page_extra_class':
						case 'video_post':
							$value = sanitize_textarea_field( $value );
							break;

						case 'video_product_url':
							$value = esc_url_raw( $value );
							break;

						default:
							$value = sanitize_text_field( $value );
							break;
					}
					update_post_meta( $post_id, $field, $value );
				} else {
					delete_post_meta( $post_id, $field );
				}
			}
		}

	}
	new Villa_Custom_Meta_Box();
}